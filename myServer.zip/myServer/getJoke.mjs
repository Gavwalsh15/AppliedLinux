#!/usr/bin/env zx
import fetch from 'node-fetch';

async function getRandomJoke(){
  const apiUrl = 'https://v2.jokeapi.dev/joke/Programming?type=single';

  const response = await fetch(apiUrl);
  const data = await response.json();

  if (data.error) {
    return 'Unable to fetch joke. Please try again later.';
  }

  return data.joke;
}

const joke = await getRandomJoke();
console.log(joke);

