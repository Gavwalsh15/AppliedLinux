function clearOutput() {
      document.getElementById("scriptOutput").innerHTML = "";
      document.body.style.backgroundColor = "pink";
    }

    async function sendToServer() {
      console.log(document.getElementById("scriptInput").value);

      let response = await fetch("http://localhost:3000/runScript", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify({
          scriptInput: document.getElementById("scriptInput").value,
          scriptOutput: "",
          moreStuff: "",
        }),
      });
      response = await response.json();
      document.getElementById("scriptOutput").innerHTML =
        response.scriptOutput;
    }

    async function runTsk() {
      let response = await fetch("http://localhost:3000/runTsk", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          tskOutput: "",
          moreStuff: "",
        }),
      });
      let responseData = await response.json();
    
      document.getElementById("date").innerHTML = responseData.date;
      document.getElementById("Cpu").innerHTML = responseData.cpuInfo;
      document.getElementById("Mem").innerHTML = responseData.memoryInfo;
    }
    
    async function getWeather() {
	  const response = await fetch('http://localhost:3000/getWeather', {
	    method: 'GET',
	    headers: {
	      'Content-Type': 'application/json',
	    },
	  });

	  const responseData = await response.json();
	  
	  
	  let jsonData = JSON.parse(responseData.scriptOutput.replace('JSON Output: ', ''));
	  
	  document.getElementById("area").innerHTML = jsonData.city + ', ' + jsonData.country;
	  document.getElementById("temperature").innerHTML = jsonData.temperature_celsius + "&deg;C";
	  document.getElementById("description").innerHTML = jsonData.description;
	  
	  
	  if(jsonData.rain_1h == 1){
	  	document.getElementById("rain").innerHTML = "Rain in last hour: Yes";
	  }else{
	  	document.getElementById("rain").innerHTML = "Rain in last hour: No";
	  }
	}
	
	function turnPink() {
      		document.body.style.backgroundColor = "pink";
      		document.querySelector(".container").style.backgroundColor = "#FC6C85";
      		document.getElementById("scriptInput").style.backgroundColor = "pink";
      		document.getElementById("scriptOutput").style.backgroundColor = "pink";
    	}
