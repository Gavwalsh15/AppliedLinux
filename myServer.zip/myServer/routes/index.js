var express = require('express');
var router = express.Router();
const { exec } = require("child_process");
const fs = require('fs')

router.get('/', function(req, res, next) {
  res.render('index', {title: 'EXPRESS'});
});

router.post('/runScript', function(req, res, next) {
  var scrObject = req.body;
  console.log(req.body);
  var stdOutString = "";
  
  try {
    fs.writeFileSync('./theZxScript.mjs', scrObject.scriptInput)
    //file written successfully
  } catch (err) {
    console.error(err)
  }

  exec('./theZxScript.mjs', (error, stdout, stderr) => {
    if (error) {
        console.log(`error: ${error.message}`);
        return;
    }
    if (stderr) {
        console.log(`stderr: ${stderr}`);
        return;
    }
    stdOutString = `${stdout}`;
    console.log(stdOutString);
    scrObject.scriptOutput = stdOutString;
    res.json(scrObject);
  });
});

//new for us
router.get('/runTsk', function (req, res, next) {
  exec('./runTsk.sh', (error, stdout, stderr) => {
    if (error) {
      console.log(`error: ${error.message}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }

    if (stderr) {
      console.log(`stderr: ${stderr}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
    
    const csvFilePath = 'system_usage.csv';
    try {
      const csvContent = fs.readFileSync(csvFilePath, 'utf8');
      const lines = csvContent.trim().split('\n');
      const lastLine = lines[lines.length - 1];

      // get the last line of the CSV
      const [date, cpuInfo, usedMemory, freeMemory, totalMemory] = lastLine.split(',');

      const scrObjectWithInfo = {
        date: date,
        cpuInfo: cpuInfo,
        memoryInfo: {
          usedMemory: usedMemory,
          freeMemory: freeMemory,
          totalMemory: totalMemory,
        },
      };

      res.json(scrObjectWithInfo);
    } catch (readError) {
      console.log(`Error reading CSV file: ${readError.message}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  });
});


router.get('/getWeather', function(req, res, next) {
  exec('./weather.sh', (error, stdout, stderr) => {
    if (error) {
      console.log(`error: ${error.message}`);
      return;
    }

    if (stderr) {
      console.log(`stderr: ${stderr}`);
      return;
    }

    const scriptOutput = stdout.trim();

    // Respond with the script output
    const responseObj = {
      scriptOutput: scriptOutput,
    };

     res.json(responseObj);
  });
});

router.get('/getProcess', function(req, res, next) {
  exec('./processManager.mjs', (error, stdout, stderr) => {
    if (error) {
      console.log(`error: ${error.message}`);
      return;
    }
    /*if (stderr) {
    //  console.log(`stderr: ${stderr}`);
    //  return;
    }*/
    //idk why it comes out as an error
    const scriptOutput = stderr.trim();

    const responseObj = {
      scriptOutput: scriptOutput,
    };

     res.json(responseObj);
  });
});

router.get('/getJoke', function(req, res, next) {
  exec('./getJoke.mjs', (error, stdout, stderr) => {
    if (error) {
      console.log(`error: ${error.message}`);
      return;
    }

    if (stderr) {
      console.log(`stderr: ${stderr}`);
      return;
    }

    const scriptOutput = stdout.trim();
    
    const responseObj = {
      scriptOutput: scriptOutput,
    };

     res.json(responseObj);
  });
});


module.exports = router;
