#!/bin/bash

get_cpu_usage() {
    echo "$(top -bn1 | grep Cpu | awk '{print $2}')%"
}

get_memory_usage() {
    used_memory=$(free -m | awk '/Mem/ {print $3}')
    free_memory=$(free -m | awk '/Mem/ {print $6}')
    total_memory=$(free -m | awk '/Mem/ {print $2}')
    echo "${used_memory}MB used, ${free_memory}MB free, ${total_memory}MB total"
}

current_date=$(date +"%H:%M:%S %d/%m/%Y")

csv_file="system_usage.csv"

if [ ! -e "$csv_file" ]; then
    echo "Date,CPU Usage,Used Memory,Free Memory,Total Memory" > "$csv_file"
fi

echo "$current_date,$(get_cpu_usage),$(get_memory_usage)" >> "$csv_file"



