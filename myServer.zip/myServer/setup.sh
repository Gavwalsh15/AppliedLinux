#!/bin/bash

# Set perms
chmod 777 setup.sh
chmod 755 theZxScript.mjs
chmod 755 runTsk.sh
chmod 755 weather.sh

#check if a command is available
check_dependency() {
  command -v "$1" >/dev/null 2>&1
}

check_dependency "jq" || sudo apt-get install -y jq
check_dependency "npm" || sudo apt-get install -y npm
check_dependency "node" || sudo apt-get install -y nodejs

# CSV file
csv_file="system_usage.csv"

# Delete existing previous
[ -f "$csv_file" ] && rm "$csv_file"

# Create a new CSV file with headers
echo "Date,CPU Usage,Memory Usage" > "$csv_file"

#Open run.html 
xdg-open "http://localhost:3000/run.html"

npm start



