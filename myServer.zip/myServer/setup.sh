#!/bin/bash

# Set perms
echo "Setting permissions..."
chmod 777 setup.sh
chmod 755 theZxScript.mjs
chmod 755 runTsk.sh
chmod 755 weather.sh

# CSV file
csv_file="system_usage.csv"

# Delete existing previous
[ -f "$csv_file" ] && rm "$csv_file"

# Create a new CSV file with headers
echo "Date,CPU Usage,Memory Usage" > "$csv_file"

# Open run.html (commented out as it may not work in all environments)
# xdg-open "http://localhost:3000/run.html"

# Start npm
echo "Starting npm..."
npm start

