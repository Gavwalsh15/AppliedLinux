#!/bin/bash

API_KEY="f2abeb0ab7900473847c986a8dd662a1"
CITY="Galway"
COUNTRY="IE"
API_ENDPOINT="http://api.openweathermap.org/data/2.5/weather?q=${CITY},${COUNTRY}&appid=${API_KEY}"

weather_data=$(curl -s "$API_ENDPOINT")

# Check if weather data is empty
if [ -z "$weather_data" ]; then
  echo "Error: Unable to fetch weather data."
  exit 1
fi

temperature_kelvin=$(echo "$weather_data" | jq -r '.main.temp')
temperature_celsius=$(echo "scale=2; $temperature_kelvin - 273.15" | bc)
description=$(echo "$weather_data" | jq -r '.weather[0].description')
humidity=$(echo "$weather_data" | jq -r '.main.humidity')
rain_1h=$(echo "$weather_data" | jq -r '.rain."1h" // 0')


#echo "Temperature (Kelvin): $temperature_kelvin"
#echo "Temperature (Celsius): $temperature_celsius"
#echo "Description: $description"
#echo "Humidity: $humidity"
#echo "Rain in the last hour: $rain_1h"

json_output=$(jq -n --arg city "$CITY" --arg country "$COUNTRY" --arg temperature_celsius "$temperature_celsius" --arg description "$description" --arg humidity "$humidity" --arg rain_1h "$rain_1h" '{city: $city, country: $country, temperature_celsius: $temperature_celsius, description: $description, humidity: $humidity, rain_1h: $rain_1h}')

echo "JSON Output: $json_output"

