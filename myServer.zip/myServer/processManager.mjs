#!/usr/bin/env zx

// Process Viewer Script

const processes = $`ps aux --sort=-%cpu | head -n 10`.toString().split('\n');

console.log('PID\t%CPU\t%MEM\tCOMMAND');
processes.slice(1).forEach((process) => {
  const [user, pid, cpu, mem, vsz, rss, tty, stat, start, time, command] = process.trim().split(/\s+/);
  console.log(`${pid}\t${cpu}\t${mem}\t${command}`);
});

